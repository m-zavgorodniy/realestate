<?php
	/* If you want to comply with E_STRICT php standards set a default timezone
	 * You can find default timezones here: http://us2.php.net/manual/en/timezones.php
	 */
	//date_default_timezone_set('Europe/Amsterdam');
	
	$wdays_labels	= array("Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Вс");
	$month_labels	= array("Январь", "Февраль", "Март", "Апрель", "Май", "Июнь", "Июль", "Август", "Сентябрь", "Октябрь", "Ноябрь", "Декабрь");
	$month_s_labels	= array("Янв", "Фев", "Мар", "Апр", "Май", "Июн", "Июл", "Авг", "Сен", "Окт", "Ноя", "Дек");

/*	$wdays_labels	= array("Mo", "Tu", "We", "Th", "Fr", "Sa", "Su");
	$month_labels	= array("January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December");
	$month_s_labels	= array("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec");*/
?>