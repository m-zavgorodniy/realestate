<?
define('SHOW_SUBQUERIES_ONLY', true);
require "view.php";
?>
