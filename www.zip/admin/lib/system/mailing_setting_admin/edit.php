<?
require dirname(__FILE__) . '/../setting_admin/edit.php';
?>