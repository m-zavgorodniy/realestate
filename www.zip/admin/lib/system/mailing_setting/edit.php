<?
require dirname(__FILE__) . '/../setting/edit.php';
?>